<?php
App::uses('FacebookInfo', 'Facebook.Lib');
class FacebookAppController extends AppController {

}
?>